# Agora Video Streaming Demo (scaffold)

This is a minimal scaffold to demonstrate a video streaming project using Agora.

Structure
- `backend/` — FastAPI token endpoint (reads `AGORA_APP_ID` and `AGORA_APP_CERT` from `.env`).
- `frontend/index.html` — Simple Agora Web SDK demo that requests token from the backend.

Quick start

1. Copy `.env.example` to `.env` and set `AGORA_APP_ID` (and `AGORA_APP_CERT` if you will generate tokens).

2. Create a Python virtual environment and install backend dependencies:

```bash
cd /path/to/agora-project
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

3. Run the backend (default port 8000):

```bash
uvicorn backend.main:app --reload --port 8000
```

4. Serve the frontend (simple option: open `frontend/index.html` in a browser, or run a static server such as `python -m http.server 8080` from the `frontend/` folder). In dev you may want to proxy `/backend` to `http://localhost:8000` or change the fetch URL in `index.html` to `http://localhost:8000/token`.

Notes
- The backend currently returns `appId` and an empty token when `AGORA_APP_CERT` is not set — this is useful for quick tests if your Agora project has App Certificate disabled. For production or when App Certificate is enabled, integrate Agora's official token builder on the server side and return a short-lived token.
- I can add token-builder integration (server-side generation of RTC tokens) if you'd like — I can either vendor the token builder code or use a known pip package.
